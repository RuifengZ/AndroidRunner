﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Scoreboard : MonoBehaviour {

    public Text scoreText;

    public int theScore;
	// Use this for initialization
	void Start () {
        theScore = 0;
	}
	
	// Update is called once per frame
	void Update () {
        scoreText.text = "Gems: " + theScore;
	}

    public void addScore()
    {
        theScore++;
    }
    public void resetS()
    {
        theScore = 0;
    }
}
