﻿using UnityEngine;
using System.Collections;

public class EnemyControl : MonoBehaviour
{

    public float eSpeed;
    public float eJump;
    public GameManager eGameManager;
    public bool eDead;

    public PlayerControl ePlayer;
    private Rigidbody2D eRigidBody;
    private Animator eAnimator;
    // Use this for initialization
    void Start()
    {
        eRigidBody = GetComponent<Rigidbody2D>();
        eGameManager = FindObjectOfType<GameManager>();
        ePlayer = FindObjectOfType<PlayerControl>();
        eDead = false;
        eAnimator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        eAnimator.SetBool("isDead", eDead);
       
        StartCoroutine("moveMent");

    }
    public IEnumerator moveMent()
    {
        yield return new WaitForSeconds(2f);
        eRigidBody.velocity = new Vector2(eSpeed, eRigidBody.velocity.y);
        eRigidBody.velocity = new Vector2(eRigidBody.velocity.x, eJump);
        yield return new WaitForSeconds(0.2f);
        eRigidBody.velocity = new Vector2(0, 0);
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            eGameManager.RestartGame();
        }
    }
}
