﻿using UnityEngine;
using System.Collections;

public class Menu : MonoBehaviour {
    public void PlayGame()
    {
        Application.LoadLevel("scene1");
    }
}
