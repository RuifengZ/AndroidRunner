﻿using UnityEngine;
using System.Collections;

public class PlayerControl : MonoBehaviour {

    public float moveSpeed;
    public float jumpForce;
    public bool grounded;
    public bool amDead;
    public LayerMask Ground;

    private Rigidbody2D myRigidBody;    
    private Collider2D myCollider;
    private Animator myAnimator;
    public GameManager theGameManager;
    // Use this for initialization
    void Start () {
        myRigidBody = GetComponent<Rigidbody2D>();
        myCollider = GetComponent<Collider2D>();
        myAnimator = GetComponent<Animator>();
        amDead = false;
    }
	
	// Update is called once per frame
	void Update () {
        if(!amDead)
        {
            grounded = Physics2D.IsTouchingLayers(myCollider, Ground);
            myAnimator.SetBool("isGrounded", grounded);
            myRigidBody.velocity = new Vector2(moveSpeed, myRigidBody.velocity.y);

            if (Input.GetKeyDown(KeyCode.Space) && grounded)
                myRigidBody.velocity = new Vector2(myRigidBody.velocity.x, jumpForce);


            var fingerCount = 0;
            foreach (Touch touch in Input.touches)
            {
                if (touch.phase != TouchPhase.Ended && touch.phase != TouchPhase.Canceled)
                    fingerCount++;
            }
            if (fingerCount > 0 && grounded)
                myRigidBody.velocity = new Vector2(myRigidBody.velocity.x, jumpForce);
        }
    }
    
    public void die()
    {
        amDead = true;
        myRigidBody.velocity = new Vector2(0, 0);
        myAnimator.SetBool("pDead", true);
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Respawn")
        {
            theGameManager.RestartGame();
        }
    }

    void OnTriggerEnter(Collider other)
    {

        Debug.Log("Tigger Active");
    }

}
