﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {
    public Transform platformGenerator;
    private Vector3 platformStartPoint;

    public PlayerControl thePlayer;    
    private Vector3 playerStartPoint;
    private Scoreboard reScore;
    private PlatDestroy[] destroyList;

    // Use this for initialization
    void Start () {
        platformStartPoint = platformGenerator.position;
        playerStartPoint = thePlayer.transform.position;
        reScore = FindObjectOfType<Scoreboard>();

    }
	
	// Update is called once per frame
	void Update () {
	
	}

    public void RestartGame()
    {
        StartCoroutine("RestartGameCo");
    }

    public IEnumerator RestartGameCo()
    {
        thePlayer.die();
        yield return new WaitForSeconds(2f);
        thePlayer.gameObject.SetActive(false);
        destroyList = FindObjectsOfType<PlatDestroy>();
        for(int a = 0; a < destroyList.Length; ++a)
        {
            destroyList[a].gameObject.SetActive(false);
        }

        thePlayer.transform.position = playerStartPoint;
        platformGenerator.position = platformStartPoint;
        reScore.resetS();
        thePlayer.amDead = false;
        thePlayer.gameObject.SetActive(true);
        Application.LoadLevel("title");
    }
}
