﻿using UnityEngine;
using System.Collections;

public class PlatformGenerate : MonoBehaviour {

    public GameObject thePlatform;
    public Transform generationPoint;
    public GameObject anEnemy;
    public GameObject gem;

    public float distanceMin;
    public float distanceMax;

    private float heightMin;
    public Transform heightMaxPoint;
    private float heightMax;
    public float maxHeightChange;
    private float heightChange;
    private int passes;


    private float platformWidth;
	// Use this for initialization
	void Start () {
        platformWidth = thePlatform.GetComponent<BoxCollider2D>().size.x;
        heightMin = (float)-1.18;
        heightMax = (float)1.25;
        passes = 4;
	}
	
	// Update is called once per frame
	void Update () {
        if (transform.position.x < generationPoint.position.x)
        {
            float distanceBetween = Random.Range(distanceMin, distanceMax);
            int numGems = Random.Range(0, 4);

            heightChange = transform.position.y + Random.Range(maxHeightChange, -maxHeightChange);
            if (heightChange > heightMax)
            {
                heightChange = heightMax;
            }
            if (heightChange < heightMin)
            {
                heightChange = heightMin;
            }
            Vector3 newPos = new Vector3(transform.position.x + platformWidth +
                distanceBetween, heightChange, transform.position.z);
            Instantiate(thePlatform, newPos, transform.rotation);

            float ex = Random.Range((float)-0.7, (float)0.7);
            Vector3 newPos2 = new Vector3(transform.position.x + platformWidth +
            distanceBetween + ex, heightChange + (float)0.39, transform.position.z);

            

            for (int i =0; i<numGems; ++i)
            {
                ex = Random.Range((float)-1.5, (float)1.5);
                newPos2 = new Vector3(transform.position.x + platformWidth +
                distanceBetween + ex, heightChange - (float)0.2, transform.position.z);
                Instantiate(gem, newPos2, transform.rotation);

            }

            if(passes <= 0)
            {
                ex = Random.Range((float)-1.5, (float)1.5);
                newPos2 = new Vector3(transform.position.x + platformWidth +
                distanceBetween + ex, heightChange - (float)0.4, transform.position.z);
                Instantiate(anEnemy, newPos2, transform.rotation);
                passes= Random.Range(0, 6);
            }


            transform.position = new Vector3(transform.position.x + platformWidth +
                distanceBetween, heightChange, transform.position.z);
            passes--;

        }
	}
}
