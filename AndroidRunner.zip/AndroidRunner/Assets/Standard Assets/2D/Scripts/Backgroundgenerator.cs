﻿using UnityEngine;

public class Backgroundgenerator : MonoBehaviour {

    public Transform genPoint;
    public GameObject background;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
        if(transform.position.x < genPoint.position.x)
        {
            transform.position = new Vector3(transform.position.x +8, transform.position.y, 0);
            Instantiate(background, transform.position, transform.rotation);
        }
	}
}
